service.blueelec.settings
