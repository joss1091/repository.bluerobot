
import xbmcgui

class notificationWindow(xbmcgui.WindowXMLDialog):

    def __init__(self, *args, **kwargs):
        self.visible = False
        self.wizTextbox = 1400
        self.wizTitle = 1399
        self.oe = kwargs['oeMain']


    def onInit(self):
        pass


    def set_notificationWindow_text(self, text):
        try:
            self.getControl(self.wizTextbox).setText(text)
        except Exception, e:
            raise

    def set_notificationWindow_title(self, title):
        try:
            self.getControl(self.wizTitle).setLabel(title)
        except Exception, e:
            raise



    def onAction(self, action):
        pass

    def onClick(self, controlID):
        pass

    def onFocus(self, controlID):
        pass
