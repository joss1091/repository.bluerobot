

import oeWindows
import sys
import xbmcaddon
import xbmcgui
import xbmc
import requests
import fcntl, socket, struct

__oe__ = sys.modules[globals()['__name__']]
__scriptid__ = 'service.subscription'
__addon__ = xbmcaddon.Addon(id=__scriptid__)
__cwd__ = __addon__.getAddonInfo('path')


__url__ = "http://192.168.50.119:8000/iptv/verify_subscription?mac_address={}"


def openWindow():
    global winOeMain, __cwd__, __oe__
    try:
        winOeMain = oeWindows.notificationWindow('notification.xml', __cwd__, 'Default', oeMain=__oe__)
        winOeMain.visible = True
        winOeMain.doModal()
    except Exception, e:
        raise

def stop_player():
    player = xbmc.Player()
    if player.isPlaying():
        player.stop()

def getHwAddr(ifname):
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    info = fcntl.ioctl(s.fileno(), 0x8927,  struct.pack('256s',ifname[:15]))
    return ':'.join(['%02x' % ord(char) for char in info[18:24]])

def verify_subscription():

    __mac_address__ = getHwAddr("eth0")
    #__mac_address__ = "68:1d:ef:08:16:4c"
    url = __url__.format(__mac_address__)

    try:
        response = requests.get(url).json()
        active = response['active']
        return active

    except Exception as e:
        xbmcgui.Dialog().notification("verificar", str(e), xbmcgui.NOTIFICATION_INFO, 5000)



winOeMain = oeWindows.notificationWindow('notification.xml', __cwd__, 'Default', oeMain=__oe__)
